function slideSlider(){
  $("#slider-scroller").css({"left":"0%","transition":"all 0s linear"});
  $("#slider-scroller").css({"left": String(parseInt($("#slider-scroller").css("left")) - 500) + "px","transition":"all 5s linear"});
  setTimeout(function(){moveSliderItem()}, 2635);
}

function moveSliderItem(){
  $("#slider-scroller div").first().detach().appendTo($("#slider-scroller"));
  slideSlider();
}

slideSlider();

/*image viewer */

/* post extension */
function goTo(number){
  $('ul.pager li:eq('+number+') a').tab('show');
  upgradePreNext(number);
}
function upgradePreNext(number){
  if (number>1){
      $('ul.pager li:eq(0)').attr("onclick","goTo("+(number-1)+")");
      $('ul.pager li:eq(0)').attr("class", "previous");
  } else {
      $('ul.pager li:eq(0)').attr("class", "disabled");
  }
   if (number<5){
      $('ul.pager li:eq(6)').attr("onclick","goTo("+(number+1)+")");
      $('ul.pager li:eq(6)').attr("class", "next");
  } else {
      $('ul.pager li:eq(6)').attr("class", "disabled");
  }
}
$(document).ready(function(){
   $('li a').on('click',function(e){
       goTo((e.target.innerHTML)-0);
 });
});
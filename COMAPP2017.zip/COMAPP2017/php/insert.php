<?php
$servername = "localhost";
$username = "id2888475_bhuvan";
$password = "comapp";
$dbname = "id2888475_comapp";
// Create connection
$con = mysqli_connect($servername, $username, $password, $dbname);
	$email   = $_POST['email'];
	$Date=$_POST['tdate'];
    $name  = $_POST['name'];
    $photo = $_POST['photo'];
    $comment    = $_POST['comment'];
    $article    = $_POST['article'];
 if(!empty(trim($comment))
 {
 $query = "INSERT INTO `comments`(`Date`,`Article`, `Name`, `Mail`, `photo`, `comment`) VALUES ('$Date','$article', '$name', '$email', '$photo', '$comment')";
echo mysqli_query($con,$query);
echo "Success";
 }
 
?>
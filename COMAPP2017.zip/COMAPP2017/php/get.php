<?php
$servername = "localhost";
$username = "id2888475_bhuvan";
$password = "comapp";
$dbname = "id2888475_comapp";
// Create connection
$con = mysqli_connect($servername, $username, $password, $dbname);
$article=$_POST['article'];
$q = "select * from comments where Article = '$article'";
$info = mysqli_query($con,$q);
	while($var = mysqli_fetch_assoc($info)){
		$rows[] = $var;
}
echo json_encode($rows);	
?>